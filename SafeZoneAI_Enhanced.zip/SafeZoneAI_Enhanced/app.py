from flask import Flask, Response, jsonify, render_template
import cv2
import csv
import io
import json
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOG = ROOT / "incidents.json"

app = Flask(__name__)

class SafeZoneMonitor:
    def __init__(self):
        self.lock = threading.Lock()
        self.camera = None
        self.running = False
        self.thread = None
        self.frame_bytes = None
        self.status = "Stopped"
        self.error = None
        self.people_count = 0
        self.incursion = False
        self.last_logged = 0.0
        self.boxes = []
        self.frame_num = 0
        self.hog = cv2.HOGDescriptor()
        self.hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

    def incidents(self):
        if not LOG.exists():
            return []
        try:
            data = json.loads(LOG.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except (json.JSONDecodeError, OSError):
            return []

    def start(self):
        with self.lock:
            if self.running:
                return True, "Monitoring is already running."
            self.error = None
            self.camera = cv2.VideoCapture(0, cv2.CAP_DSHOW)
            if not self.camera.isOpened():
                self.camera.release()
                self.camera = cv2.VideoCapture(0)
            if not self.camera.isOpened():
                self.camera = None
                self.status = "Camera unavailable"
                self.error = "Camera unavailable. Check Windows camera permissions and close other camera apps."
                return False, self.error
            self.running = True
            self.status = "Monitoring"
            self.thread = threading.Thread(target=self._loop, daemon=True)
            self.thread.start()
            return True, "Monitoring started."

    def stop(self):
        with self.lock:
            self.running = False
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=2)
        with self.lock:
            if self.camera is not None:
                self.camera.release()
                self.camera = None
            self.status = "Stopped"
            self.incursion = False
        return True, "Monitoring stopped."

    def _loop(self):
        while True:
            with self.lock:
                running = self.running
                camera = self.camera
            if not running or camera is None:
                break
            ok, frame = camera.read()
            if not ok:
                with self.lock:
                    self.error = "Unable to read camera frame."
                    self.status = "Camera error"
                    self.running = False
                break

            frame = cv2.resize(frame, (640, 480))
            h, w = frame.shape[:2]
            x1, y1, x2, y2 = int(w * .32), int(h * .18), int(w * .78), int(h * .88)
            self.frame_num += 1
            if self.frame_num % 6 == 1:
                found, weights = self.hog.detectMultiScale(
                    frame, winStride=(8, 8), padding=(8, 8), scale=1.05
                )
                self.boxes = [
                    (int(x), int(y), int(bw), int(bh), float(score))
                    for (x, y, bw, bh), score in zip(found, weights)
                ]

            intrusion = False
            for x, y, bw, bh, confidence in self.boxes:
                foot_x, foot_y = x + bw // 2, y + bh
                inside = x1 <= foot_x <= x2 and y1 <= foot_y <= y2
                intrusion = intrusion or inside
                color = (0, 0, 255) if inside else (0, 255, 0)
                cv2.rectangle(frame, (x, y), (x + bw, y + bh), color, 2)
                cv2.putText(frame, "PERSON", (x, max(20, y - 8)),
                            cv2.FONT_HERSHEY_SIMPLEX, .6, color, 2)

            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 2)
            cv2.putText(frame, "RESTRICTED ZONE", (x1, max(25, y1 - 10)),
                        cv2.FONT_HERSHEY_SIMPLEX, .6, (0, 0, 255), 2)
            status_text = "INTRUSION ALERT!" if intrusion else "Monitoring - no intrusion"
            cv2.putText(frame, status_text, (15, 35), cv2.FONT_HERSHEY_SIMPLEX,
                        .8, (0, 0, 255) if intrusion else (0, 200, 0), 2)

            now = datetime.now()
            if intrusion and now.timestamp() - self.last_logged >= 10:
                incident = {
                    "timestamp": now.isoformat(timespec="seconds"),
                    "event": "restricted_zone_intrusion",
                    "source": "webcam"
                }
                incidents = self.incidents()
                incidents.append(incident)
                try:
                    LOG.write_text(json.dumps(incidents, indent=2), encoding="utf-8")
                except OSError:
                    pass
                self.last_logged = now.timestamp()

            ok, encoded = cv2.imencode(".jpg", frame)
            if ok:
                with self.lock:
                    self.frame_bytes = encoded.tobytes()
                    self.incursion = intrusion
                    self.people_count = len(self.boxes)
                    self.status = "Intrusion detected" if intrusion else "Monitoring"
            time.sleep(0.01)

        with self.lock:
            if self.status not in ("Camera unavailable", "Camera error"):
                self.status = "Stopped"

    def get_frame(self):
        with self.lock:
            return self.frame_bytes

    def get_status(self):
        with self.lock:
            return {
                "running": self.running,
                "status": self.status,
                "error": self.error,
                "intrusion": self.incursion,
                "people_count": self.people_count
            }

monitor = SafeZoneMonitor()

@app.route("/")
def index():
    return render_template("index.html")

@app.post("/api/start")
def start_monitoring():
    ok, message = monitor.start()
    return jsonify({"ok": ok, "message": message, **monitor.get_status()}), (200 if ok else 503)

@app.post("/api/stop")
def stop_monitoring():
    ok, message = monitor.stop()
    return jsonify({"ok": ok, "message": message, **monitor.get_status()})

@app.get("/api/status")
def status():
    return jsonify(monitor.get_status())

@app.get("/api/incidents")
def incidents():
    data = monitor.incidents()
    return jsonify({"incidents": list(reversed(data[-500:]))})

@app.get("/api/analytics")
def analytics():
    events = monitor.incidents()
    today = datetime.now().date()
    days = []
    for offset in range(6, -1, -1):
        day = today - timedelta(days=offset)
        count = 0
        for item in events:
            try:
                if datetime.fromisoformat(item.get("timestamp", "")).date() == day:
                    count += 1
            except (ValueError, TypeError):
                continue
        days.append({"day": day.strftime("%a"), "date": day.isoformat(), "count": count})
    return jsonify({
        "total": len(events),
        "today": sum(1 for item in events if str(item.get("timestamp", "")).startswith(today.isoformat())),
        "last7days": sum(day["count"] for day in days),
        "days": days
    })

def generate_frames():
    while True:
        frame = monitor.get_frame()
        if frame is None:
            time.sleep(0.1)
            continue
        yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + frame + b"\r\n")
        time.sleep(0.03)

@app.get("/video_feed")
def video_feed():
    return Response(generate_frames(), mimetype="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/export.csv")
def export_csv():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Timestamp", "Event", "Source"])
    for item in monitor.incidents():
        writer.writerow([item.get("timestamp", ""), item.get("event", ""), item.get("source", "")])
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=safezone_incidents.csv"}
    )

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
