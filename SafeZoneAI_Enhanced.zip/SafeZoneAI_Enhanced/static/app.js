const $ = (id) => document.getElementById(id);
let toastTimer, soundEnabled = false, previousIntrusion = false, lastStatus = null, incidentsCache = [], analyticsCache = null;

function toast(message) {
  const el = $('toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function formatTimestamp(value) {
  if (!value) return 'Unknown time';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleString([], {month:'short', day:'numeric', hour:'2-digit', minute:'2-digit', second:'2-digit'});
}
function playAlert() {
  if (!soundEnabled) return;
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();
    oscillator.type = 'sine'; oscillator.frequency.value = 880;
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.12, ctx.currentTime + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.35);
    oscillator.connect(gain); gain.connect(ctx.destination);
    oscillator.start(); oscillator.stop(ctx.currentTime + 0.36);
    oscillator.onended = () => ctx.close();
  } catch (_) {}
}
function setStatus(data) {
  lastStatus = data;
  const running = !!data.running;
  const intrusion = !!data.intrusion;
  $('statusValue').textContent = data.status || 'Unknown';
  $('statusNote').textContent = data.error || (running ? 'Camera monitoring is active' : 'Ready to start monitoring');
  $('peopleValue').textContent = data.people_count ?? 0;
  $('intrusionValue').textContent = intrusion ? 'ALERT' : 'Clear';
  $('intrusionNote').textContent = intrusion ? 'Person inside restricted zone' : 'No intrusion currently detected';
  $('intrusionCard').classList.toggle('alerting', intrusion);
  $('intrusionDot').className = 'tiny-dot ' + (intrusion ? '' : 'green-dot');
  $('statusDot').className = 'tiny-dot ' + (running ? 'green-dot' : '');
  $('startBtn').disabled = running;
  $('stopBtn').disabled = !running;
  $('liveLabel').classList.toggle('online', running && !intrusion);
  $('liveLabel').classList.toggle('alert', intrusion);
  $('liveLabel').querySelector('span').textContent = intrusion ? 'INTRUSION' : (running ? 'LIVE' : 'OFFLINE');
  $('connectionPulse').className = 'pulse ' + (intrusion ? 'alert' : (running ? 'online' : ''));
  $('connectionText').textContent = intrusion ? 'ZONE ALERT ACTIVE' : (running ? 'SYSTEM MONITORING' : 'SYSTEM STANDBY');
  $('controlDot').className = 'control-status-dot ' + (intrusion ? 'alert' : (running ? 'online' : ''));
  $('controlMessage').textContent = data.error || (intrusion ? 'Intrusion detected — review the event log' : (running ? 'Camera connected and analyzing frames' : 'Camera is idle'));
  if (running) {
    $('cameraFeed').hidden = false;
    if (!$('cameraFeed').src || $('cameraFeed').src !== new URL('/video_feed', location.href).href) $('cameraFeed').src = '/video_feed';
    $('cameraPlaceholder').hidden = true;
  } else {
    $('cameraFeed').hidden = true;
    $('cameraFeed').removeAttribute('src');
    $('cameraPlaceholder').hidden = false;
  }
  if (intrusion && !previousIntrusion) playAlert();
  previousIntrusion = intrusion;
}
async function refreshStatus() {
  try {
    const r = await fetch('/api/status', {cache:'no-store'});
    if (!r.ok) throw new Error('status request failed');
    setStatus(await r.json());
  } catch (_) {
    $('statusNote').textContent = 'Cannot reach the local backend';
    $('controlMessage').textContent = 'Backend connection unavailable';
  }
}
function matchesFilter(item, query, filter) {
  const haystack = `${item.timestamp || ''} ${item.event || ''} ${item.source || ''}`.toLowerCase();
  if (query && !haystack.includes(query)) return false;
  if (!item.timestamp) return filter === 'all';
  const date = new Date(item.timestamp);
  if (Number.isNaN(date.getTime())) return filter === 'all';
  const now = new Date();
  if (filter === 'today') return date.toDateString() === now.toDateString();
  if (filter === '7days') return date >= new Date(now.getTime() - 7 * 86400000);
  return true;
}
function renderIncidents() {
  const query = $('incidentSearch').value.trim().toLowerCase();
  const filter = $('incidentFilter').value;
  const items = incidentsCache.filter(item => matchesFilter(item, query, filter));
  $('visibleCount').textContent = `${items.length} event${items.length === 1 ? '' : 's'}`;
  $('eventFooter').textContent = items.length ? `Showing ${items.length} matching event${items.length === 1 ? '' : 's'}` : 'No matching events';
  const list = $('incidentList');
  if (!items.length) {
    const hasAny = incidentsCache.length > 0;
    list.innerHTML = `<div class="empty-state"><span>${hasAny ? '⌕' : '✓'}</span><b>${hasAny ? 'No matching events' : 'All clear'}</b><small>${hasAny ? 'Try changing the search or date filter.' : 'No incidents logged yet. Start monitoring to detect activity.'}</small></div>`;
    return;
  }
  list.innerHTML = items.slice(0, 100).map(item => `<div class="incident-item"><span class="incident-symbol">!</span><div class="incident-details"><b>Restricted zone intrusion</b><small>${escapeHtml(item.event || 'restricted_zone_intrusion')} · ${escapeHtml(item.source || 'unknown source')}</small></div><span class="incident-time">${escapeHtml(formatTimestamp(item.timestamp))}</span></div>`).join('');
}
async function refreshIncidents() {
  try {
    const r = await fetch('/api/incidents', {cache:'no-store'});
    if (!r.ok) throw new Error('incident request failed');
    const data = await r.json();
    incidentsCache = data.incidents || [];
    $('incidentCount').textContent = incidentsCache.length;
    renderIncidents();
  } catch (_) {
    $('incidentList').innerHTML = '<div class="empty-state"><span>!</span><b>Could not load incidents</b><small>Check that the local Flask server is running.</small></div>';
  }
}
function renderAnalytics(data) {
  analyticsCache = data;
  $('todayCount').textContent = data.today ?? 0;
  $('weekCount').textContent = data.last7days ?? 0;
  $('weeklyTotal').textContent = `${data.last7days ?? 0} events this week`;
  const chart = $('barChart');
  const days = data.days || [];
  if (!days.length) { chart.innerHTML = '<div class="chart-empty">No activity data yet.</div>'; return; }
  const max = Math.max(1, ...days.map(d => Number(d.count) || 0));
  chart.innerHTML = days.map(d => {
    const count = Number(d.count) || 0;
    const height = count ? Math.max(8, count / max * 100) : 3;
    return `<div class="bar-column" title="${escapeHtml(d.date)}: ${count} incident(s)"><span class="bar-count">${count}</span><div class="bar-track"><div class="bar-fill" style="height:${height}%"></div></div><span class="bar-day">${escapeHtml(d.day)}</span></div>`;
  }).join('');
}
async function refreshAnalytics() {
  try {
    const r = await fetch('/api/analytics', {cache:'no-store'});
    if (!r.ok) throw new Error('analytics request failed');
    renderAnalytics(await r.json());
  } catch (_) {
    $('barChart').innerHTML = '<div class="chart-empty">Analytics are temporarily unavailable.</div>';
  }
}
$('startBtn').addEventListener('click', async () => {
  $('startBtn').disabled = true;
  try {
    const r = await fetch('/api/start', {method:'POST'});
    const d = await r.json();
    setStatus(d);
    toast(d.message || 'Start request complete');
    if (!r.ok || !d.ok) toast(d.error || d.message || 'Could not start camera');
  } catch (_) { toast('Could not contact the local backend'); }
});
$('stopBtn').addEventListener('click', async () => {
  try {
    const r = await fetch('/api/stop', {method:'POST'});
    const d = await r.json();
    setStatus(d);
    toast(d.message || 'Monitoring stopped');
  } catch (_) { toast('Could not contact the local backend'); }
});
$('refreshBtn').addEventListener('click', async () => {
  await Promise.all([refreshIncidents(), refreshAnalytics()]);
  toast('Incident history refreshed');
});
$('incidentSearch').addEventListener('input', renderIncidents);
$('incidentFilter').addEventListener('change', renderIncidents);
$('soundBtn').addEventListener('click', () => {
  soundEnabled = !soundEnabled;
  $('soundBtn').setAttribute('aria-pressed', String(soundEnabled));
  $('soundText').textContent = soundEnabled ? 'Sound on' : 'Sound off';
  $('soundIcon').textContent = soundEnabled ? '♫' : '♪';
  toast(soundEnabled ? 'Alert sound enabled for new intrusion transitions' : 'Alert sound disabled');
  if (soundEnabled) playAlert();
});
function updateClock() {
  $('clock').textContent = new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit', second:'2-digit', hour12:false});
}
document.querySelectorAll('.nav-item').forEach(link => link.addEventListener('click', () => {
  document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
  link.classList.add('active');
}));
updateClock();
setInterval(updateClock, 1000);
refreshStatus();
refreshIncidents();
refreshAnalytics();
setInterval(refreshStatus, 1400);
setInterval(refreshIncidents, 6000);
setInterval(refreshAnalytics, 15000);
