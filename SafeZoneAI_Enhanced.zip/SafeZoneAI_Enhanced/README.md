# SafeZone AI — Enhanced Local Website

This enhanced version preserves the existing Flask + OpenCV HOG detection backend and adds a refreshed responsive command-center UI.

## Included features
- Live webcam monitoring with start/stop controls
- Current people count, system status, and intrusion state
- Incident history with search and date filters
- Seven-day incident analytics
- CSV export of recorded incidents
- Optional browser-generated sound when a new intrusion state begins
- Responsive desktop/tablet/mobile layout

## Run on Windows
1. Extract this folder.
2. Open this folder (the one containing `app.py`) in VS Code.
3. Open Terminal → New Terminal.
4. Activate your existing virtual environment if you have one in the parent folder:
   ```powershell
   ..\.venv\Scripts\Activate.ps1
   ```
   If the environment is inside this folder instead, use:
   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```
5. Install dependencies if needed:
   ```powershell
   python -m pip install -r requirements.txt
   ```
6. Run:
   ```powershell
   python app.py
   ```
7. Open http://127.0.0.1:5000

## Important
- Keep the terminal open while using the dashboard.
- Camera processing runs on the computer running Flask.
- Incident records remain local in `incidents.json`; CSV export downloads a copy.
- The browser sound toggle is off by default. Enable it using the button in the header.
- This prototype uses OpenCV's HOG detector, which can miss people or generate false positives. It is not a certified security system.
- The Flask development server is for local testing only. Do not expose it directly to the public internet.

## Preserving your current project
This ZIP is a separate upgraded copy. Keep your existing `SafeZoneAI_Website` folder as your rollback backup until you have tested the new copy.
